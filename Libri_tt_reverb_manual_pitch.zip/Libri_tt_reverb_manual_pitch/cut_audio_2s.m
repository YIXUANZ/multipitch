
% MATLAB script to load, process, and save all .mat files in a directory

% Define the directory path
directoryPath = '/Users/zhangyixuan/Documents/PHD/research/multipitch/reverb/Libri_tt_reverb_manual_pitch/';

% Get a list of all .mat files in the directory
matFiles = dir(fullfile(directoryPath, '*.mat'));

% Loop through each file
for k = 1:length(matFiles)
    % Full path to the current file
    filePath = fullfile(directoryPath, matFiles(k).name);
    
    % Load the file
    loadedData = load(filePath);

    % Process or modify your data here
    % Example: If the file contains a variable 'a', you can access it with
    % a = loadedData.a;
    % Then modify 'a' as needed
    data = loadedData.data;
    data = data(1:16000);
    loadedData.data = data;
    % Save the data back to the same file
    save(filePath, '-struct', 'loadedData');
end
