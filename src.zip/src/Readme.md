
## Installation

To install the package, clone the repo and execute the following command in the rvd root folder:

```bash
$ pip install .
```

<!-- The package will be made available on PyPI. To install it, execute the following command within your Python environment:

```bash
$ pip install rvd
``` -->

<!-- We tested the code with Python version 3.8.18 and pip version 23.3.1. -->

## Usage

### Computing the voicing decision from audio

```python
import multipitch


# Assign the path of the audio file
audio_filename = ...

# Specify the path to the pre-trained model file
model_file = ...

# Set the voicing threshold
voicing_threshold = ...

# Choose a device to use for inference
device = 'cuda:0'

# Create the model with the specified model file, voicing threshold, and device
model = rvd.Model(model_file, voicing_threshold, device)

# Compute voicing decision using first gpu
vd = model.predict(audio_filename)

```


